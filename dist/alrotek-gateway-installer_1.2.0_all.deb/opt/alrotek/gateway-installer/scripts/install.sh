#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=scripts/common.sh
source "$SCRIPT_DIR/common.sh"
ORIGINAL_ARGS=("$@")

REPO_URL="$DEFAULT_REPO_URL"
REF="$DEFAULT_REF"
ENV_FILE="$INSTALLER_ROOT/.env"
APP_DIR=""
ENABLE_AUTOSTART=true
ENABLE_NETWORK_RECOVERY=false
ENABLE_AUTOLOGIN=false
RUN_AFTER_INSTALL=false
REBOOT_AFTER_INSTALL=false
INSTALL_SYSTEM_PACKAGES=true
INSTALL_USER_OVERRIDE=""
PYTHON_BIN="${GATEWAY_PYTHON_BIN:-python3}"

usage() {
  cat <<'EOF'
Uso: install.sh [opciones]

  --repo-url URL             Repositorio del gateway.
  --ref RAMA_O_VERSION       Rama, tag o commit (predeterminado: master).
  --python-bin RUTA          Python 3.10+ utilizado para crear el entorno.
  --app-dir RUTA             Directorio de instalación.
  --env-file RUTA            Archivo .env que se copiará.
  --autostart                Abrir la interfaz al iniciar sesión (predeterminado).
  --no-autostart             Abrir la interfaz manualmente; el servicio sigue activo.
  --service                  Compatibilidad: Gateway siempre usa el servicio.
  --network-recovery         Autorizar recuperación de wlan0 y reboot sin contraseña.
  --autologin                Configurar autologin de LightDM.
  --run                      Abrir la interfaz al terminar (requiere escritorio).
  --reboot                   Reiniciar el equipo al terminar.
  --skip-system-packages     No ejecutar apt.
  --install-user USUARIO     Usuario propietario de la instalación.
  --help                     Mostrar esta ayuda.
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --repo-url) REPO_URL="${2:?Falta URL}"; shift 2 ;;
    --ref) REF="${2:?Falta rama o versión}"; shift 2 ;;
    --python-bin) PYTHON_BIN="${2:?Falta intérprete}"; shift 2 ;;
    --app-dir) APP_DIR="${2:?Falta ruta}"; shift 2 ;;
    --env-file) ENV_FILE="${2:?Falta ruta}"; shift 2 ;;
    --autostart) ENABLE_AUTOSTART=true; shift ;;
    --no-autostart) ENABLE_AUTOSTART=false; shift ;;
    --service) shift ;;
    --no-service) fail "Gateway ahora requiere el servicio. Use --no-autostart para ocultar la interfaz." ;;
    --network-recovery) ENABLE_NETWORK_RECOVERY=true; shift ;;
    --autologin) ENABLE_AUTOLOGIN=true; shift ;;
    --run) RUN_AFTER_INSTALL=true; shift ;;
    --reboot) REBOOT_AFTER_INSTALL=true; shift ;;
    --skip-system-packages) INSTALL_SYSTEM_PACKAGES=false; shift ;;
    --install-user) INSTALL_USER_OVERRIDE="${2:?Falta usuario}"; shift 2 ;;
    --help) usage; exit 0 ;;
    *) fail "Opción desconocida: $1" ;;
  esac
done

require_linux
if [ -n "$INSTALL_USER_OVERRIDE" ]; then
  export GATEWAY_INSTALL_USER="$INSTALL_USER_OVERRIDE"
fi
detect_install_user
APP_DIR="${APP_DIR:-$INSTALL_HOME/gateway}"
validate_app_dir
[ -f "$ENV_FILE" ] || fail "No existe el archivo de configuración: $ENV_FILE"
require_sudo
acquire_installer_lock "${ORIGINAL_ARGS[@]}"

SERVICE_WAS_ACTIVE=false
RUNTIME_MUTATED=false
trap finish_service_operation EXIT

if service_is_active; then
  SERVICE_WAS_ACTIVE=true
  log "Deteniendo temporalmente $GATEWAY_SERVICE_NAME..."
  as_root systemctl stop "$GATEWAY_SERVICE_NAME"
fi
require_runtime_stopped

if [ "$INSTALL_SYSTEM_PACKAGES" = true ]; then
  log "[1/7] Instalando dependencias del sistema..."
  as_root apt-get update
  as_root apt-get install -y git python3 python3-venv python3-pip python3-tk
  if [ "$ENABLE_NETWORK_RECOVERY" = true ]; then
    as_root apt-get install -y sudo iproute2 rfkill
  fi
else
  log "[1/7] Omitiendo dependencias del sistema."
fi
require_supported_python "$PYTHON_BIN"

log "[2/7] Descargando la versión $REF..."
prepare_gateway_state
RUNTIME_MUTATED=true
checkout_ref "$REPO_URL" "$REF"
mark_installation

log "[3/7] Copiando configuración..."
as_root install -m 600 -o "$INSTALL_USER" -g "$INSTALL_GROUP" \
  "$ENV_FILE" "$APP_DIR/.env"

log "[4/7] Preparando entorno virtual..."
if [ -x "$APP_DIR/venv/bin/python" ] &&
  ! python_is_supported "$APP_DIR/venv/bin/python"; then
  log "El entorno existente usa una versión incompatible; se volverá a crear."
  run_as_install_user "$PYTHON_BIN" -m venv --clear "$APP_DIR/venv"
elif [ ! -x "$APP_DIR/venv/bin/python" ]; then
  run_as_install_user "$PYTHON_BIN" -m venv "$APP_DIR/venv"
fi
run_as_install_user "$APP_DIR/venv/bin/pip" install --upgrade pip
[ -f "$APP_DIR/requirements.txt" ] ||
  fail "El repositorio no contiene requirements.txt."
run_as_install_user "$APP_DIR/venv/bin/pip" install -r "$APP_DIR/requirements.txt"
verify_runtime

log "[5/7] Creando comando de inicio..."
create_start_script

log "[6/7] Aplicando opciones de escritorio..."
if [ "$ENABLE_NETWORK_RECOVERY" = true ]; then
  configure_network_recovery
else
  as_root rm -f -- "$NETWORK_RECOVERY_RULE"
fi
configure_desktop_launcher
if [ "$ENABLE_AUTOSTART" = true ]; then
  configure_autostart
else
  remove_autostart
fi
configure_systemd_service true
SERVICE_WAS_ACTIVE=false
if [ "$ENABLE_AUTOLOGIN" = true ]; then
  configure_autologin
fi

log "[7/7] Instalación terminada."
show_installed_version

if [ "$RUN_AFTER_INSTALL" = true ]; then
  log "Abriendo la interfaz de Gateway..."
  run_as_install_user nohup "$APP_DIR/start.sh" 9>&- >/dev/null 2>&1 &
fi

if [ "$REBOOT_AFTER_INSTALL" = true ]; then
  log "Reiniciando el equipo..."
  as_root reboot
fi
